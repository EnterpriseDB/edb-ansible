#!/bin/bash
ssh-keyscan -H 192.168.48.2 >> ~/.ssh/known_hosts
