#!/bin/bash
ssh-keyscan -H 172.24.0.2 >> ~/.ssh/known_hosts
